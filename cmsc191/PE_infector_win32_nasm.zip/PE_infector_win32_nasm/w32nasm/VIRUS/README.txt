For CMSC 191: CNSEC
[jchermocilla@up.edu.ph]


Assemble:
	>..\BIN\NASMW -fwin32 MSGBOX1.asm

Link:
	>..\BIN\GOLINK MSGBOX1.obj kernel32.dll user32.dll