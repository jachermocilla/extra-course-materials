For CMSC 191: CNSEC
[11/2018 jchermocilla@up.edu.ph]

==>Tested on Windows XP only<==

PLEASE BE CAREFUL!!!


===== VICTIM =====
Assemble Victim:
	>..\BIN\NASMW -fwin32 msgbox1.asm

Link Victim:
	>..\BIN\GOLINK msgbox1.obj kernel32.dll user32.dll

Test Victim:
	>msgbox1.exe


===== SHINGLES32 =====
Assemble Virus:
	>..\BIN\NASMW -fwin32 shingles32.asm

Link Virus:
	>..\BIN\GOLINK shingles32.obj

Set the .text section writable flag using CFF Explorer (See Top Level Dir)

Infect:
	>shingles32.exe
